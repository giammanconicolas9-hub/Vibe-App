# 🎯 LocalRequest - App Annunci Invertiti

**L'app che inverte il modello degli annunci - Ora con backend sincronizzato per tutta Italia!**

---

## 🚀 COSA È LOCALREQUEST?

Invece di cercare tra migliaia di annunci, **pubblichi quello che cerchi** e ricevi contatti da chi lo ha!

### Come funziona:
1. **Tu pubblichi:** "Cerco iPhone 14 Pro a Roma"
2. **Il sistema trova:** Persone a Roma che vendono iPhone
3. **Notifica istantanea:** Invio notifica ai venditori
4. **Contatto diretto:** Ti contattano su WhatsApp

---

## 📱 DEMO

**🌐 Frontend:** https://ff4pgsqs3wk3i.ok.kimi.link

---

## ✨ FUNZIONALITÀ

### Per chi cerca:
- ✅ Pubblica richieste in 30 secondi
- ✅ Ricevi contatti mirati
- ✅ Zero spam - solo chi ha quello che cerchi
- ✅ Notifiche in tempo reale

### Per chi offre:
- ✅ Intercetta domanda attiva
- ✅ Clienti qualificati
- ✅ Zero sprechi di tempo
- ✅ Contatto diretto via WhatsApp

---

## 🛠️ TECNOLOGIE

### Frontend:
- React 18 + TypeScript
- Tailwind CSS + shadcn/ui
- Vite (build tool)
- PWA ready

### Backend:
- Node.js + Express
- SQLite (database)
- JWT (autenticazione)
- REST API

---

## 📁 STRUTTURA PROGETTO

```
/mnt/okcomputer/output/
│
├── 📱 FRONTEND (React App)
│   ├── app/
│   │   ├── src/
│   │   │   ├── pages/          # Login, Home, Create, Profile
│   │   │   ├── context/        # Auth, Notifications
│   │   │   ├── services/       # API calls
│   │   │   └── ...
│   │   ├── dist/               # Build pronta
│   │   └── package.json
│   └── ...
│
├── ⚙️ BACKEND (Node.js API)
│   ├── localrequest-backend-sqlite/
│   │   ├── server.js           # Server completo
│   │   ├── Dockerfile          # Per Docker
│   │   ├── render.yaml         # Per Render.com
│   │   └── package.json
│   └── ...
│
└── 📖 DOCUMENTAZIONE
    ├── DEPLOY-GUIDA.md         # Come deployare
    ├── GUIDA_BUILD_APK.md      # Come creare APK
    └── README-COMPLETO.md      # Questo file
```

---

## 🚀 AVVIO RAPIDO

### 1. Frontend (Sviluppo)
```bash
cd app
npm install
npm run dev
```

### 2. Backend (Sviluppo)
```bash
cd localrequest-backend-sqlite
npm install
npm start
```

### 3. Build Produzione
```bash
cd app
npm run build
```

---

## 📡 API ENDPOINTS

### Autenticazione
```
POST   /api/auth/register       # Registrazione
POST   /api/auth/login          # Login
GET    /api/auth/me             # Profilo utente
PUT    /api/auth/me             # Aggiorna profilo
```

### Richieste
```
GET    /api/requests/feed        # Feed personalizzato
GET    /api/requests/my         # Le mie richieste
POST   /api/requests            # Crea richiesta
GET    /api/requests/:id        # Dettaglio richiesta
POST   /api/requests/:id/contact # Contatta
```

### Notifiche
```
GET    /api/notifications       # Lista notifiche
GET    /api/notifications/count # Conta non lette
PUT    /api/notifications/:id/read
PUT    /api/notifications/read-all
```

---

## 🗄️ DATABASE

### SQLite - Struttura

**Tabella `users`:**
- id, name, whatsapp, photo, city, province, preferences

**Tabella `requests`:**
- id, user_id, title, description, category, city, province, images, budget, urgency, status, views, contacts, expires_at

**Tabella `notifications`:**
- id, user_id, request_id, type, read, created_at

---

## 🌍 DEPLOY

### Frontend (Già Deployato)
✅ **URL:** https://ff4pgsqs3wk3i.ok.kimi.link

### Backend (Da Deployare)
Vedi `DEPLOY-GUIDA.md` per:
- Render.com (gratuito)
- Railway.app (gratuito)
- VPS/Dedicato
- Docker

---

## 📱 APP MOBILE

### Opzione 1: PWA (Consigliata)
1. Apri l'URL nel browser
2. "Aggiungi a schermata Home"
3. Funziona come app nativa!

### Opzione 2: APK
Vedi `GUIDA_BUILD_APK.md` per:
- Bubblewrap (5 minuti)
- Android Studio (completo)

---

## 🎯 CATEGORIE DISPONIBILI

1. 📱 Elettronica
2. 🚗 Auto
3. 🏠 Immobili
4. 💼 Lavoro
5. 🔧 Servizi
6. 🛋️ Arredamento
7. 👕 Abbigliamento
8. 🏋️ Sport
9. 📚 Libri
10. 🎮 Giochi
11. 🎵 Musica
12. 🐕 Animali

---

## 🔒 SICUREZZA

- ✅ JWT per autenticazione
- ✅ Password non memorizzate (solo WhatsApp)
- ✅ Validazione input
- ✅ SQL injection protection (prepared statements)
- ✅ CORS configurato

---

## 📊 STATISTICHE

Ogni utente vede:
- Numero richieste disponibili nella sua zona
- Numero sue richieste attive
- Notifiche non lette
- Views e contatti ricevuti

---

## 🆘 SUPPORTO

### Problemi comuni:

**"Cannot connect to backend"**
- Verifica che il backend sia avviato
- Controlla CORS settings
- Verifica URL in `.env`

**"Database locked"**
- Normale con SQLite sotto carico
- Per produzione alta, passa a PostgreSQL

**"Token expired"**
- Rieffettua il login
- Il token scade dopo 30 giorni

---

## 🚀 ROADMAP

### v1.0 (Attuale)
- ✅ Registrazione/Login
- ✅ Pubblicazione richieste
- ✅ Matching zona + categorie
- ✅ Notifiche
- ✅ Contatto WhatsApp

### v1.1 (Futuro)
- 🔄 Chat in-app
- 🔄 Valutazioni utenti
- 🔄 Filtri avanzati

### v2.0 (Futuro)
- 🔄 Notifiche push reali
- 🔄 Geolocalizzazione precisa
- 🔄 Pagamenti in-app

---

## 💰 COSTI

| Componente | Costo |
|------------|-------|
| Frontend hosting | Gratuito (Kimi) |
| Backend Render | Gratuito |
| Database SQLite | Gratuito |
| Dominio (opz.) | ~10€/anno |
| **TOTALE** | **GRATIS** |

---

## 🤝 CONTRIBUIRE

1. Fork del progetto
2. Crea branch: `git checkout -b feature/nuova`
3. Commit: `git commit -am 'Aggiungi feature'`
4. Push: `git push origin feature/nuova`
5. Pull Request

---

## 📄 LICENZA

MIT License - Libero uso e modifica

---

## 👨‍💻 AUTORE

Creato con ❤️ per semplificare gli scambi locali in Italia

---

**🎉 PRONTO PER USARE!**

1. Apri https://ff4pgsqs3wk3i.ok.kimi.link
2. Registrati
3. Pubblica la tua prima richiesta!

**Buona ricerca!** 🔍
