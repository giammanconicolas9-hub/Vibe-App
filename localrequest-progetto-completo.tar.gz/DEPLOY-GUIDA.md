# 🚀 Guida Deploy - LocalRequest

Questa guida ti spiega come rendere LocalRequest disponibile per tutta Italia con backend sincronizzato.

## 📁 Struttura Progetto

```
/mnt/okcomputer/output/
├── app/                          # Frontend React
│   ├── dist/                     # Build pronta
│   └── src/                      # Codice sorgente
├── localrequest-backend-sqlite/  # Backend Node.js + SQLite
│   ├── server.js                 # Server completo
│   ├── Dockerfile                # Per Docker
│   └── render.yaml               # Per Render.com
└── DEPLOY-GUIDA.md               # Questo file
```

---

## 🌐 Step 1: Deploy Frontend (Già Fatto!)

**URL Frontend:** https://ff4pgsqs3wk3i.ok.kimi.link

Il frontend è già deployato e funzionante!

---

## ⚙️ Step 2: Deploy Backend

### Opzione A: Render.com (Consigliata - Gratuita)

1. **Crea account** su https://render.com

2. **Crea nuovo Web Service:**
   - Click "New" → "Web Service"
   - Connetti il tuo repository GitHub (o usa "Deploy from Git URL")
   - Seleziona la cartella `localrequest-backend-sqlite`

3. **Configura:**
   ```
   Name: localrequest-backend
   Environment: Node
   Build Command: npm install
   Start Command: node server.js
   ```

4. **Aggiungi Environment Variables:**
   ```
   NODE_ENV=production
   JWT_SECRET=il-tuo-super-segreto-lungo-almeno-32-caratteri
   ```

5. **Crea Disk (per database):**
   ```
   Name: data
   Mount Path: /app/data
   Size: 1 GB
   ```

6. **Click "Create Web Service"**

7. **Copia l'URL** (es: `https://localrequest-backend.onrender.com`)

---

### Opzione B: Railway.app (Gratuita)

1. **Crea account** su https://railway.app

2. **New Project** → **Deploy from GitHub repo**

3. **Seleziona** la cartella `localrequest-backend-sqlite`

4. **Aggiungi variabili d'ambiente** nelle Settings

5. **Deploy!**

---

### Opzione C: VPS/Dedicato (Linux)

1. **Connettiti al server:**
   ```bash
   ssh user@tuo-server.com
   ```

2. **Installa Node.js:**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **Clona progetto:**
   ```bash
   git clone <tuo-repo>
   cd localrequest-backend-sqlite
   ```

4. **Installa e avvia:**
   ```bash
   npm install
   npm start
   ```

5. **Con PM2 (per produzione):**
   ```bash
   npm install -g pm2
   pm2 start server.js --name localrequest-backend
   pm2 startup
   pm2 save
   ```

6. **Con Nginx (reverse proxy):**
   ```nginx
   server {
       listen 80;
       server_name api.tuodominio.com;
       
       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

---

### Opzione D: Docker

1. **Build immagine:**
   ```bash
   cd localrequest-backend-sqlite
   docker build -t localrequest-backend .
   ```

2. **Avvia container:**
   ```bash
   docker run -d \
     -p 3000:3000 \
     -v $(pwd)/data:/app/data \
     -e JWT_SECRET=il-tuo-segreto \
     --name localrequest-backend \
     localrequest-backend
   ```

---

## 🔗 Step 3: Collega Frontend al Backend

1. **Modifica il file `.env` nel frontend:**
   ```bash
   cd app
   ```

2. **Aggiorna l'URL del backend:**
   ```env
   VITE_API_URL=https://tuo-backend-url.com/api
   ```

3. **Ricostruisci:**
   ```bash
   npm run build
   ```

4. **Rideploya il frontend**

---

## ✅ Verifica Funzionamento

1. **Test API:**
   ```bash
   curl https://tuo-backend-url.com/api/health
   ```
   
   Dovresti vedere:
   ```json
   {
     "success": true,
     "message": "LocalRequest API is running"
   }
   ```

2. **Registra utente** nell'app

3. **Pubblica una richiesta**

4. **Verifica notifiche** da altro dispositivo/città

---

## 📊 Monitoraggio

### Logs su Render:
- Vai su Dashboard → il tuo servizio → Logs

### Logs su VPS:
```bash
pm2 logs localrequest-backend
```

### Logs su Docker:
```bash
docker logs localrequest-backend
```

---

## 🔒 Sicurezza

1. **Cambia JWT_SECRET** (usa password lunga e casuale)
2. **Abilita HTTPS** (Render lo fa automatico)
3. **Backup database** periodicamente
4. **Aggiorna dipendenze** regolarmente

---

## 💾 Backup Database

Il database SQLite è in `data/localrequest.db`

**Backup manuale:**
```bash
scp user@server:/app/data/localrequest.db ./backup/
```

**Backup automatico (cron):**
```bash
# Ogni giorno alle 3 AM
0 3 * * * cp /app/data/localrequest.db /backup/localrequest-$(date +\%Y\%m\%d).db
```

---

## 🆘 Troubleshooting

### Errore "Cannot find module"
```bash
rm -rf node_modules
npm install
```

### Database locked
- SQLite non supporta molte connessioni simultanee
- Per alta concorrenza, passa a PostgreSQL

### CORS error
- Verifica che `FRONTEND_URL` sia corretto
- Oppure usa `*` per permettere tutti

---

## 🎯 Prossimi Passi

1. ✅ Deploy backend
2. ✅ Configura dominio custom (opzionale)
3. ✅ Aggiungi SSL/HTTPS
4. ✅ Setup monitoring
5. ✅ Configura backup automatici

---

## 📞 Supporto

Per problemi o domande:
- Documentazione Express: https://expressjs.com
- Documentazione SQLite: https://sqlite.org
- Community Node.js: https://nodejs.org

---

**🎉 La tua app è ora disponibile per tutta Italia!**
